#include <AsyncCppApplication.h>

using namespace Async;

int main(int argc, char **argv)
{
  CppApplication app;
  app.exec();
}
